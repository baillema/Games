Fonts Gallery
by Creative Design


To install a new font:
Go to control panel
Select fonts
Go to 'File' - 'Install new font'
Select the directory where you have unzipped the font file.